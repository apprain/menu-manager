<?php
/**
 * appRain CMF
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Inc. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */

/**
 * Developed by: Reazaul Karim
 *
 * Created a slide show specailly for whitecloud theme
 */
class Component_Menumanager_Register extends appRain_Base_Component
{
    /**
     * Initialize the basic
     * Resource on load
     */
    public function init()
    {
        App::Module('Hook')
            ->setHookName('CSS')
            ->setAction("register_css_code")
            ->Register(get_class($this),"register_css_code");

        App::Module('Hook')
            ->setHookName('Javascript')
            ->setAction("register_javascript_code")
            ->Register(get_class($this),"register_javascript_code");
			
		App::Module('Hook')
            ->setHookName('CategorySet')
            ->setAction("register_definition")
            ->Register(get_class($this),"register_categoryset_defination");
			
        App::Module('Hook')
            ->setHookName('Controller')
           ->setAction("register_controller")
           ->Register(get_class($this),"register_controller");
           
        App::Module('Hook')
            ->setHookName('InterfaceBuilder')
            ->setAction("update_definition")
            ->Register(get_class($this),"interfacebuilder_update_definition");   
            
         App::Module('Hook')
            ->setHookName('Javascript')
            ->setAction("register_javascript_code")
            ->Register(get_class($this),"register_javascript_code");    
			
		App::Module('Hook')
            ->setHookName('UI')
            ->setAction("menu_manager_nave")
            ->Register(get_class($this),"add_html");			
   					
    }
	
	public function add_html(){
		return App::Component('Menumanager')->Helper('Data')->CreateMenuTree('nav navbar-nav'); 
	}

    public function init_on_install(){}

    public function init_on_uninstall(){}

    public function register_css_code()
    {
		return App::Helper('Utility')->fetchFile($this->attachMyPath('css/styles.css'));
    }

    public function register_categoryset_defination()
    {
        $srcpaths = Array();
        $srcpaths[] =   array(
			'type'=>'menulist',
            'path'=>$this->attachMyPath('category_set/menulist.xml')
		);
        return $srcpaths;
    }
	
    public function register_controller()
    {
        $srcpaths = Array();
        $srcpaths[] =   array(
            'name'=>'menumanager',
            'controller_path'=>$this->attachMyPath('controllers')
        );
        return $srcpaths;
    }

    public function interfacebuilder_update_definition($send)
    {
        if(isset($send['component']['child']))
        {
            $send['component']['child'][] = Array(
                "title"=>"Menu Manager",
                "items"=>Array(					
                    array(
                        "title"=>"Manage website Menus",
                        "link"=>"/menumanager/ddboard")
                    ),
                    "adminicon" => array("type"=>"filePath",'location'=>'/component/menumanager/icon/logo.jpg'));
            return $send;
        }
    }
    
    public function register_javascript_code()
    {
        return App::Helper('Utility')->fetchFile($this->attachMyPath('js/jquery.mjs.nestedSortable.js'));
    }
}