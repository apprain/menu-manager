<?php
/**
 * appRain CMF
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Inc. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/documents
 */
class menumanagerController extends appRain_Base_Core
{
    public $name = 'MenuManager';
    
    public function __preDispatch(){
		
	}
    
    public function deletemenuAction(){
        $this->layout = 'empty';
        $id = $this->post['id'];   
        $ParentCategory = App::Model("Category")->findByParentId($id);    
        if(!empty($ParentCategory)){
            echo "Please delete child category first!";
            exit;
        }        
        
        App::Model("Category")->DeleteById($id);
    }
    
    public function updatedataAction(){
        $this->layout = 'empty';
        $id = str_replace('list_','',$this->post['id']);       
        App::Model("Category")
            ->setId($id)   
            ->setTitle($this->post['title'])
            ->setDescription($this->post['link'])
            ->Save();
    }
    
    public function addmenuAction(){
        $this->layout = 'empty';
         App::Model("Category")
                        ->setId(null)   
                        ->setTitle('New Menu')
                        ->setType('menulist')
                        ->setParentid(0)                        
                        ->setGeneric(99999)
                        ->Save();
    }
        
	
	public function savedataAction(){

		$sorting = $_POST['sorting'];
		$relation = $_GET['list'];
        if(!empty($relation)){
            foreach($relation as $catid=>$parent){
                $parent = (strtolower($parent)=='null') ? '0' : $parent; 
                $Category = App::CategorySet()->findById($catid);
                App::Model("Category")
                    ->setId($catid)    
                    ->setParentid($parent)
                    ->Save();                                                             
            }
        }
		$list= explode('&',$_POST['sorting']);
        if(!empty($list)){
             foreach($list as $key=>$str){
                if(empty($str)) continue;
                
                $arr = explode('=',$str);
                $Category = App::CategorySet()->findById($arr[1]);
               
                if(!empty($Category)){
                    $arr[0] = trim($arr[0]);
                    $sortorder = $arr[0]+10;
                    App::Model("Category")
                        ->setId($Category['id'])   
                        ->setParentid($Category['parentid'])                        
                        ->setGeneric($sortorder)
                        ->Save();
                }
            }
        }
		echo '1';
		exit;
	}
	
	

    public function ddboardAction()
    {
		$this->layout = 'simple';
	
    }
}
