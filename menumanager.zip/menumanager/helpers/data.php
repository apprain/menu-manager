<?php
/**
 * appRain CMF
 *
 * LICENSE
 *
 * This source file is subject to the MIT license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.opensource.org/licenses/mit-license.php
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@apprain.com so we can send you a copy immediately.
 *
 * @copyright  Copyright (c) 2010 appRain, Team. (http://www.apprain.com)
 * @license    http://www.opensource.org/licenses/mit-license.php MIT license
 *
 * HELP
 *
 * Official Website
 * http://www.apprain.com/
 *
 * Download Link
 * http://www.apprain.com/download
 *
 * Documents Link
 * http ://www.apprain.com/docs
 */
 
class Component_Menumanager_Helpers_Data extends appRain_Base_Objects
{
     function CreateMenuTree($class='sortable'){
		$this->get_Menu_recursion(0,$class);		
	}
    
    public function get_Menu_recursion($pid = NULl,$class='')
    {
        $child_arr_arr = App::Model("Category")->findAll("type='menulist' AND parentid=$pid  ORDER BY generic ASC");                  
        if (!empty($child_arr_arr['data'])) {
			echo "<ul class=\"{$class}\">";
            foreach ($child_arr_arr['data'] as $key => $val) {                
                    $List = App::Model("Category")->find("type='menulist' and parentid={$val['id']} ");
                    
                    $url = empty($val['description']) ? '#' : App::Utility()->codeFormated($val['description']);
                    if(empty($List)){
                       /* if(substr($val['title'],0,2)=="__"){
                            echo "<li class=\"divider\">";
                        }
                        else*/
                        {
                            echo "<li>";
                            echo "<a href=\"{$url}\" >{$val['title']}</a>";
                        }
                    }
                    else {
                        if( $class != 'dropdown-menu'){
                            echo "<li class=\"dropdown\">";
                            echo "<a href=\"{$url}\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" >{$val['title']} <span class=\"caret\"></span></a>";
                        }
                        else{
                            echo "<li class=\"dropdown-submenu\">";
                            echo "<a href=\"{$url}\" >{$val['title']} <span class=\"caret\"></span></a>";
                        }
					}                    
                    $this->get_Menu_recursion($val['id'],'dropdown-menu');
				echo '</li>';               
            }
			echo '</ul>';
        }
        else {
            return;
        }
    }
    
    
    function menuTree($class='sortable'){
		$this->get_category_recursion(0,$class);		
	}
    
	public function get_category_recursion($pid = NULl,$class='')
    {
        $child_arr_arr = App::Model("Category")->findAll("type='menulist' AND parentid=$pid  ORDER BY generic ASC");
        
        if (!empty($child_arr_arr['data'])) {
			echo "<ol class=\"{$class}\">";
            foreach ($child_arr_arr['data'] as $key => $val) {
                echo "<li id=\"list_{$val['id']}\">";
				echo 	"<div><span class=\"disclose\"><span></span></span><span class=\"title\">{$val['title']}</span><p class=\"hand\" style=\"float:right\"><a href=\"#\" link=\"{$val['description']}\" class=\"edit\">Edit</a> <a href=\"javascript:void(0)\" data=\"{$val['id']}\" class=\"remove-menu\">Remove</a></p></div>";
					 $this->get_category_recursion($val['id'],'');
				echo '</li>';               
            }
			echo '</ol>';
        }
        else {
            return;
        }
    }
	
}